package org.sgx.mfm.block;

import org.sgx.mfm.init.ItemInit;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class MySecondBlock extends Block {
	
	public static final BooleanProperty LIGHTING = BooleanProperty.create("lighting");
	
	public static VoxelShape MODEL = Shapes.empty();
	
	public MySecondBlock(Properties properties) {
		
		super(properties.lightLevel(state -> {
			
			return state.getValue(LIGHTING) ? 15 : 0;
			
		}));
		
		MODEL = Shapes.join(MODEL, Shapes.box(0.3125, 0, 0.3125, 0.6875, 0.0625, 0.6875), BooleanOp.OR);
		MODEL = Shapes.join(MODEL, Shapes.box(0.4375, 0.0625, 0.4375, 0.5625, 0.5625, 0.5625), BooleanOp.OR);
		MODEL = Shapes.join(MODEL, Shapes.box(0.25, 0.25, 0.25, 0.75, 0.4375, 0.75), BooleanOp.OR);
		MODEL = Shapes.join(MODEL, Shapes.box(0.3125, 0.4375, 0.3125, 0.6875, 0.5, 0.6875), BooleanOp.OR);
		
		this.registerDefaultState(this.defaultBlockState().setValue(LIGHTING, false));
		
	}
	
	@Override
	protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
		
		builder.add(LIGHTING);
		
		super.createBlockStateDefinition(builder);
		
	}
	
	@SuppressWarnings({"deprecation"})
	@Override
	public InteractionResult use(BlockState state, Level world, BlockPos position, Player player, InteractionHand hand, BlockHitResult result) {
		
		if(!world.isClientSide()) {
			
			if(player.getItemInHand(hand).getItem().equals(ItemInit.MY_FIRST_ITEM.get())) {
				
				world.setBlock(position, state.cycle(LIGHTING), 4);
				
				return InteractionResult.CONSUME;
				
			}
			
		}
		
		return super.use(state, world, position, player, hand, result);
		
	}
	
}