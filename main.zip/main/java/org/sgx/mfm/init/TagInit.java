package org.sgx.mfm.init;

import org.sgx.mfm.MyFirstMod;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.Tag;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

public final class TagInit {
	
	public static final class Blocks {
		
		public static final Tag.Named<Block> MY_FIRST_BLOCKS = mod("my_first_blocks");
		
		private static Tag.Named<Block> mod(String path) {
			
			return BlockTags.bind(new ResourceLocation(MyFirstMod.MOD_ID, path).toString());
			
		}
		
	}
	public static final class Items {
		
		public static final Tag.Named<Item> MY_FIRST_ITEMS = mod("my_first_items");
		
		private static Tag.Named<Item> mod(String path) {
			
			return ItemTags.bind(new ResourceLocation(MyFirstMod.MOD_ID, path).toString());
			
		}
		
	}
	
}