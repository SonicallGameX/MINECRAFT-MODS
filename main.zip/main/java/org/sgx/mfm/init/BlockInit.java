package org.sgx.mfm.init;

import java.util.function.Function;

import org.sgx.mfm.MyFirstMod;
import org.sgx.mfm.block.MySecondBlock;

import com.google.common.base.Supplier;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.MaterialColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class BlockInit {
	
	public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MyFirstMod.MOD_ID);
	public static final DeferredRegister<Item> ITEMS = ItemInit.ITEMS;
	
	public static final RegistryObject<Block> MY_FIRST_BLOCK = register("my_first_block", () -> new Block(BlockBehaviour.Properties.of(Material.METAL, MaterialColor.COLOR_RED).strength(3.0f).sound(SoundType.AMETHYST).requiresCorrectToolForDrops()), object -> () -> new BlockItem(object.get(), new Item.Properties().tab(MyFirstMod.MY_FIRST_TAB)));
	public static final RegistryObject<Block> MY_FIRST_BLOCK_ORE = register("my_first_block_ore", () -> new Block(BlockBehaviour.Properties.of(Material.METAL, MaterialColor.COLOR_RED).strength(3.0f).sound(SoundType.STONE).requiresCorrectToolForDrops()), object -> () -> new BlockItem(object.get(), new Item.Properties().tab(MyFirstMod.MY_FIRST_TAB)));
	public static final RegistryObject<Block> MY_FIRST_BLOCK_DEEPSLATE_ORE = register("my_first_block_deepslate_ore", () -> new Block(BlockBehaviour.Properties.of(Material.METAL, MaterialColor.COLOR_RED).strength(3.0f).sound(SoundType.DEEPSLATE).requiresCorrectToolForDrops()), object -> () -> new BlockItem(object.get(), new Item.Properties().tab(MyFirstMod.MY_FIRST_TAB)));
	public static final RegistryObject<Block> MY_SECOND_BLOCK = register("my_second_block", () -> new MySecondBlock(BlockBehaviour.Properties.copy(Blocks.OAK_PLANKS).noOcclusion().dynamicShape().noCollission().instabreak().sound(SoundType.BAMBOO)), object -> () -> new BlockItem(object.get(), new Item.Properties().tab(MyFirstMod.MY_FIRST_TAB)));
	
	private static <T extends Block> RegistryObject<T> registerBlock(final String name, final Supplier<? extends T> block) {
		
		return BLOCKS.register(name, block);
		
	}
	private static <T extends Block> RegistryObject<T> register(final String name, final Supplier<? extends T> block, Function<RegistryObject<T>, Supplier<? extends Item>> item) {
		
		RegistryObject<T> object = registerBlock(name, block);
		
		ITEMS.register(name, item.apply(object));
		
		return object;
		
	}
	
}